// ===== PINES MOTORES =====
const int A1_PIN = 33;
const int A2_PIN = 32;
const int PA_PIN = 25;

const int B1_PIN = 27;
const int B2_PIN = 14;
const int PB_PIN = 26;

// ===== SWITCH =====
const int SWITCH_PIN = 13;

// Velocidad mínima (ajusta si no giran)
const int VELOCIDAD_MINIMA = 60;

void setup() {
  // Motores
  pinMode(A1_PIN, OUTPUT);
  pinMode(A2_PIN, OUTPUT);
  pinMode(PA_PIN, OUTPUT);

  pinMode(B1_PIN, OUTPUT);
  pinMode(B2_PIN, OUTPUT);
  pinMode(PB_PIN, OUTPUT);

  // Switch (pull-down externo)
  pinMode(SWITCH_PIN, INPUT);

  Serial.begin(9600);
  Serial.println("Motores solo adelante, velocidad minima");
}

void loop() {
  int estadoSwitch = digitalRead(SWITCH_PIN);

  if (estadoSwitch == HIGH) {
    // ---- ADELANTE ----
    digitalWrite(A1_PIN, HIGH); //DERECHO
    digitalWrite(A2_PIN, LOW); //DERECHO

    //digitalWrite(B1_PIN, HIGH);
    //digitalWrite(B2_PIN, LOW);

    analogWrite(PA_PIN, VELOCIDAD_MINIMA);
    //analogWrite(PB_PIN, VELOCIDAD_MINIMA);
  } else {
    // ---- PARADOS ----
    analogWrite(PA_PIN, 0);
    analogWrite(PB_PIN, 0);
  }

  delay(0);
}
