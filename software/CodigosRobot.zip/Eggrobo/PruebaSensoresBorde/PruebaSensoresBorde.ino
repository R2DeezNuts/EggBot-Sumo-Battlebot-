// ===== PARAMETROS QRE1113 =====
#define TIMEOUT_US    3000
#define UMBRAL_CERCA  250  

// ===== SENSORES =====
#define SENSOR_ESQ_IZQ   22
#define SENSOR_ESQ_DER   21
#define SENSOR_ESQ_TIZQ  19
#define SENSOR_SHARP     35  

// ===== PINES MOTORES =====
const int A1_PIN = 33;
const int A2_PIN = 32;
const int PA_PIN = 25;

const int B1_PIN = 27;
const int B2_PIN = 14;
const int PB_PIN = 26;

// ===== SWITCH =====
const int SWITCH_PIN = 13;

// ===== VELOCIDAD =====
const int VELOCIDAD_A = 60; 
const int VELOCIDAD_B = 55;
const int VELOCIDAD_RAPIDA = 190; 

// ===== ESTADOS =====
bool switchAnterior = HIGH;  
bool enMarcha = false;
bool frenando = false;
unsigned long tiempoFrenada = 0;
unsigned long tiempoInicioMarcha = 0;
const int TIEMPO_RAMPA = 1500;  

unsigned long leerQRE(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH);
  delayMicroseconds(10);

  pinMode(pin, INPUT);
  unsigned long t0 = micros();

  while (digitalRead(pin) == HIGH) {
    if (micros() - t0 > TIMEOUT_US) return TIMEOUT_US;
  }
  return micros() - t0;
}

void pararMotores() {
  analogWrite(PA_PIN, 0);
  analogWrite(PB_PIN, 0);
}

void avanzarMotores(int velA, int velB) {
  digitalWrite(A1_PIN, HIGH);
  digitalWrite(A2_PIN, LOW);
  analogWrite(PA_PIN, velA);

  digitalWrite(B1_PIN, HIGH);
  digitalWrite(B2_PIN, LOW);
  analogWrite(PB_PIN, velB);
}

void retrocederMotores(int velA, int velB) {
  digitalWrite(A1_PIN, LOW);
  digitalWrite(A2_PIN, HIGH);
  analogWrite(PA_PIN, velA);

  digitalWrite(B1_PIN, LOW);
  digitalWrite(B2_PIN, HIGH);
  analogWrite(PB_PIN, velB);
}

void girarIzquierda(int velocidad) {
  // Motor A (Izq) hacia atras
  digitalWrite(A1_PIN, LOW);
  digitalWrite(A2_PIN, HIGH);
  analogWrite(PA_PIN, velocidad);

  // Motor B (Der) hacia adelante
  digitalWrite(B1_PIN, HIGH);
  digitalWrite(B2_PIN, LOW);
  analogWrite(PB_PIN, velocidad);
}

void setup() {
  // Motores
  pinMode(A1_PIN, OUTPUT);
  pinMode(A2_PIN, OUTPUT);
  pinMode(PA_PIN, OUTPUT);

  pinMode(B1_PIN, OUTPUT);
  pinMode(B2_PIN, OUTPUT);
  pinMode(PB_PIN, OUTPUT);

  // Switch a GND
  pinMode(SWITCH_PIN, INPUT_PULLUP);

  // Arranque seguro
  pararMotores();

  Serial.begin(115200);
  Serial.println("\n=== SISTEMA INICIADO (PARADO) ===");
}

void loop() {
  // ===== LECTURA SWITCH =====
  bool lecturaSwitch = digitalRead(SWITCH_PIN);
  bool switchActivo  = (lecturaSwitch == LOW);

  Serial.print("[SWITCH] RAW=");
  Serial.print(lecturaSwitch);
  Serial.println(switchActivo ? " (ACTIVO)" : " (INACTIVO)");

  if (!switchActivo) {
    if (enMarcha) Serial.println("[SISTEMA] Switch OFF -> Paro y reseteo");
    enMarcha = false;
    frenando = false;
    pararMotores();
    switchAnterior = lecturaSwitch;
    return;
  }

  if (lecturaSwitch == LOW && switchAnterior == HIGH) {
    enMarcha = true;
    tiempoInicioMarcha = millis();
    Serial.println("[SISTEMA] Switch ACTIVADO -> INICIO MARCHA");
  }

  switchAnterior = lecturaSwitch;

  unsigned long vIzq  = leerQRE(SENSOR_ESQ_IZQ);
  unsigned long vDer  = leerQRE(SENSOR_ESQ_DER);
  unsigned long vTIzq = leerQRE(SENSOR_ESQ_TIZQ);

  bool izqCerca  = (vIzq  > UMBRAL_CERCA);
  bool derCerca  = (vDer  > UMBRAL_CERCA);
  bool tIzqCerca = (vTIzq > UMBRAL_CERCA);

  bool izqLejos  = !izqCerca;
  bool derLejos  = !derCerca;
  bool tIzqLejos = !tIzqCerca;

  Serial.print("[QRE] IZQ=");
  Serial.print(vIzq);
  Serial.print(izqCerca ? " (CERCA)" : " (LEJOS)");

  Serial.print(" | DER=");
  Serial.print(vDer);
  Serial.print(derCerca ? " (CERCA)" : " (LEJOS)");

  Serial.print(" | TIZQ=");
  Serial.print(vTIzq);
  Serial.println(tIzqCerca ? " (CERCA)" : " (LEJOS)");

  if (enMarcha) {
    if (frenando) {
      if (millis() - tiempoFrenada > 500) {
        Serial.println("[LOGICA] Fin frenada -> PARAR");
        pararMotores();
        frenando = false;
        enMarcha = false;
      }
    } else {
      bool algunLejos = izqLejos || derLejos || tIzqLejos;

      if (algunLejos) {
        Serial.println("[LOGICA] Detectado LEJOS -> FRENADA ASISTIDA");
        retrocederMotores(VELOCIDAD_A, VELOCIDAD_B);
        frenando = true;
        tiempoFrenada = millis();
      } else {
        Serial.println("[LOGICA] Todos CERCA -> AVANZAR");
        
        // Calculo de rampa de aceleracion
        int velA_actual = VELOCIDAD_A;
        int velB_actual = VELOCIDAD_B;
        unsigned long tiempoTranscurrido = millis() - tiempoInicioMarcha;

        if (tiempoTranscurrido < TIEMPO_RAMPA) {
          // Fase 1: Rampa inicial (1 segundo)
          velA_actual = map(tiempoTranscurrido, 0, TIEMPO_RAMPA, 0, VELOCIDAD_A);
          velB_actual = map(tiempoTranscurrido, 0, TIEMPO_RAMPA, 0, VELOCIDAD_B);
          avanzarMotores(velA_actual, velB_actual);
          Serial.println("[MOTOR] Rampa inicial");
        } else {
          // Fase 2: Busqueda y Ataque (Sharp)
          int sharpVal = analogRead(SENSOR_SHARP);
          Serial.print("[SHARP] Val="); Serial.println(sharpVal);
          if (sharpVal < 200) { 
            // No detecta nada -> Girar Izquierda para buscar
            Serial.println("[LOGICA] Nada detectado -> BUSCANDO (Giro Izq)");
            girarIzquierda(VELOCIDAD_A); 
          } else {
            if (sharpVal > 800) {
              Serial.println("[LOGICA] Objetivo CERCA -> ATAQUE NORMAL");
              avanzarMotores(VELOCIDAD_A, VELOCIDAD_B);
            } else {
              Serial.println("[LOGICA] Objetivo LEJOS -> ACERON RAPIDO");
              avanzarMotores(VELOCIDAD_RAPIDA, VELOCIDAD_RAPIDA);
            }
          }
        }
      }
    }
    
  } else {
    Serial.println("[LOGICA] Esperando nuevo flanco");
    pararMotores();
    Serial.println("[MOTOR] PARADOS");
  }

  Serial.println("------------------------------");
}
