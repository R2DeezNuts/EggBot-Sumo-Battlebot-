
#define TIMEOUT_US    3000
#define UMBRAL_CERCA  250 

// ===== SENSORES =====
#define SENSOR_ESQ_IZQ   22
#define SENSOR_ESQ_DER   21
#define SENSOR_ESQ_TIZQ  19

// ===== PINES MOTORES =====
const int A1_PIN = 32;
const int A2_PIN = 33;
const int PA_PIN = 25;

const int B1_PIN = 27;
const int B2_PIN = 14;
const int PB_PIN = 26;

// ===== SWITCH =====
const int SWITCH_PIN = 13;

// ===== VELOCIDADES =====
const int VELOCIDAD_AVANCE = 70;
const int VELOCIDAD_FRENO  = 80;
const int VELOCIDAD_GIRO   = 70;

// ===== ESTADOS =====
bool switchAnterior = HIGH;   // pull-up
bool sistemaActivo = false;

// ===== LECTURA QRE1113 (RC) =====
unsigned long leerQRE(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH);
  delayMicroseconds(10);

  pinMode(pin, INPUT);
  unsigned long t0 = micros();

  while (digitalRead(pin) == HIGH) {
    if (micros() - t0 > TIMEOUT_US) return TIMEOUT_US;
  }
  return micros() - t0;
}

// ===== CONTROL MOTORES =====
void pararMotores() {
  analogWrite(PA_PIN, 0);
  analogWrite(PB_PIN, 0);
}

void avanzarMotores(int vel) {
  digitalWrite(A1_PIN, HIGH);
  digitalWrite(A2_PIN, LOW);
  analogWrite(PA_PIN, vel);

  digitalWrite(B1_PIN, HIGH);
  digitalWrite(B2_PIN, LOW);
  analogWrite(PB_PIN, vel);
}

void retrocederMotores(int vel) {
  digitalWrite(A1_PIN, LOW);
  digitalWrite(A2_PIN, HIGH);
  analogWrite(PA_PIN, vel);

  digitalWrite(B1_PIN, LOW);
  digitalWrite(B2_PIN, HIGH);
  analogWrite(PB_PIN, vel);
}

void girarIzquierda(int vel) {
  // Motor A atrás
  digitalWrite(A1_PIN, LOW);
  digitalWrite(A2_PIN, HIGH);
  analogWrite(PA_PIN, vel);

  // Motor B adelante
  digitalWrite(B1_PIN, HIGH);
  digitalWrite(B2_PIN, LOW);
  analogWrite(PB_PIN, vel);
}

void setup() {
  pinMode(A1_PIN, OUTPUT);
  pinMode(A2_PIN, OUTPUT);
  pinMode(PA_PIN, OUTPUT);

  pinMode(B1_PIN, OUTPUT);
  pinMode(B2_PIN, OUTPUT);
  pinMode(PB_PIN, OUTPUT);

  pinMode(SWITCH_PIN, INPUT_PULLUP);

  pararMotores();

  Serial.begin(115200);
  Serial.println("\n=== SUMO BOT LISTO ===");
}

void loop() {

  // ===== SWITCH (armado) =====
  bool lecturaSwitch = digitalRead(SWITCH_PIN);
  bool switchON = (lecturaSwitch == LOW);

  if (!switchON) {
    sistemaActivo = false;
    pararMotores();
    delay(100);
    return;
  }

  if (lecturaSwitch == LOW && switchAnterior == HIGH) {
    sistemaActivo = true;
    Serial.println("[SISTEMA] ACTIVADO");
  }
  switchAnterior = lecturaSwitch;

  if (!sistemaActivo) return;

  // ===== LECTURA SENSORES =====
  unsigned long vIzq  = leerQRE(SENSOR_ESQ_IZQ);
  unsigned long vDer  = leerQRE(SENSOR_ESQ_DER);
  unsigned long vTIzq = leerQRE(SENSOR_ESQ_TIZQ);

  bool bordeDetectado =
      (vIzq  >= UMBRAL_CERCA) ||
      (vDer  >= UMBRAL_CERCA) ||
      (vTIzq >= UMBRAL_CERCA);

  // ===== DEBUG =====
  Serial.print("[QRE] ");
  Serial.print(vIzq); Serial.print(" | ");
  Serial.print(vDer); Serial.print(" | ");
  Serial.println(vTIzq);

  if (bordeDetectado) {
    Serial.println("[BORDE] Detectado");

    //Frenada activa
    Serial.println("[ACCION] Frenada ATRÁS");
    retrocederMotores(VELOCIDAD_FRENO);
    delay(500);

    //Giro izquierda
    Serial.println("[ACCION] Giro IZQUIERDA");
    girarIzquierda(VELOCIDAD_GIRO);
    delay(1000);

    //Retoma avance
    Serial.println("[ACCION] Avance");
    avanzarMotores(VELOCIDAD_AVANCE);
  } else {
    avanzarMotores(VELOCIDAD_AVANCE);
  }

  delay(20);
}