// Sensores digitales
const int sensorD1 = 22;
const int sensorD2 = 23;
const int sensorD3 = 19;
const int sensorD4 = 21;
const int sensorD5 = 18;

// Sensores analógicos
const int sensorA1 = 35;
const int sensorA2 = 32;

void setup() {
  Serial.begin(9600);

  // Configurar pines digitales como entrada
  pinMode(sensorD1, INPUT);
  pinMode(sensorD2, INPUT);
  pinMode(sensorD3, INPUT);
  pinMode(sensorD4, INPUT);
  pinMode(sensorD5, INPUT);

  Serial.println("Lectura de sensores IR: Digitales (22,23,19,21,18) y Analógicos (35,32)");
}

void loop() {
  // Leer digitales
  int estadoD1 = digitalRead(sensorD1);
  int estadoD2 = digitalRead(sensorD2);
  int estadoD3 = digitalRead(sensorD3);
  int estadoD4 = digitalRead(sensorD4);
  int estadoD5 = digitalRead(sensorD5);

  // Leer analógicos
  int valorA1 = analogRead(sensorA1);
  int valorA2 = analogRead(sensorA2);

  // Imprimir resultados
  Serial.print("D22:");
  Serial.print(estadoD1);
  Serial.print(" | D23:");
  Serial.print(estadoD2);
  Serial.print(" | D19:");
  Serial.print(estadoD3);
  Serial.print(" | D21:");
  Serial.print(estadoD4);
  Serial.print(" | D18:");
  Serial.print(estadoD5);

  Serial.print(" | A35:");
  Serial.print(valorA1);
  Serial.print(" | A32:");
  Serial.println(valorA2);

  delay(200);
}