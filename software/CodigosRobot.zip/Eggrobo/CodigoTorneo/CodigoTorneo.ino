
const int A1_PIN = 33;
const int A2_PIN = 32;
const int PA_PIN = 25;

const int B1_PIN = 27;
const int B2_PIN = 14;
const int PB_PIN = 26;

const int SENSOR_OP = 18; 

const int SWITCH_PIN = 13;


const int VEL_GIRO      = 30;
const int VEL_PLACAR    = 60;
const int VEL_UN_MOTOR  = 60;


const unsigned long TIEMPO_PLACAR = 300; 
const unsigned long TIEMPO_ESPERA_SWITCH = 5000; 

unsigned long tiempoPlacar = 0;
bool enPlaca = false;

unsigned long tiempoActivacionSwitch = 0;
bool esperandoArranque = false;

// ===== FUNCIONES =====
void pararMotores() {
  digitalWrite(A1_PIN, LOW);
  digitalWrite(A2_PIN, LOW);
  digitalWrite(B1_PIN, LOW);
  digitalWrite(B2_PIN, LOW);
  analogWrite(PA_PIN, 0);
  analogWrite(PB_PIN, 0);
}

void girarBusqueda() {
  digitalWrite(A1_PIN, HIGH);
  digitalWrite(A2_PIN, LOW);

  digitalWrite(B1_PIN, LOW);
  digitalWrite(B2_PIN, HIGH);

  analogWrite(PA_PIN, VEL_GIRO);
  analogWrite(PB_PIN, VEL_GIRO);
}

void avanzarAmbos(int velA, int velB) {
  digitalWrite(A1_PIN, HIGH);
  digitalWrite(A2_PIN, LOW);
  analogWrite(PA_PIN, velA);

  digitalWrite(B1_PIN, HIGH);
  digitalWrite(B2_PIN, LOW);
  analogWrite(PB_PIN, velB);
}

void avanzarSoloMotorA() {
  digitalWrite(A1_PIN, HIGH);
  digitalWrite(A2_PIN, LOW);
  analogWrite(PA_PIN, VEL_UN_MOTOR);

  analogWrite(PB_PIN, 0);
}

void setup() {
  pinMode(A1_PIN, OUTPUT);
  pinMode(A2_PIN, OUTPUT);
  pinMode(PA_PIN, OUTPUT);

  pinMode(B1_PIN, OUTPUT);
  pinMode(B2_PIN, OUTPUT);
  pinMode(PB_PIN, OUTPUT);

  pinMode(SENSOR_OP, INPUT);
  pinMode(SWITCH_PIN, INPUT_PULLUP);

  pararMotores();

  Serial.begin(115200);
  Serial.println("=== SUMOBOT ATAQUE ===");
}

// ===== LOOP =====
void loop() {
  static bool switchActivoPrevio = false;
  bool switchActivo = (digitalRead(SWITCH_PIN) == LOW);

  if (switchActivo && !switchActivoPrevio) {
    esperandoArranque = true;
    tiempoActivacionSwitch = millis();
    enPlaca = false;
    pararMotores();
    Serial.println(">> SWITCH ACTIVADO: ESPERANDO 5s...");
  }
  switchActivoPrevio = switchActivo;

  if (!switchActivo) {
    pararMotores();
    enPlaca = false;
    esperandoArranque = false;
    return;
  }

  if (esperandoArranque) {
    pararMotores();
    if (millis() - tiempoActivacionSwitch >= TIEMPO_ESPERA_SWITCH) {
      esperandoArranque = false;
      Serial.println(">> INICIO");
    } else {
      delay(10);
      return;
    }
  }

  bool detectado = (digitalRead(SENSOR_OP) == HIGH);
  unsigned long ahora = millis();

  if (detectado) {
    if (!enPlaca) {
      enPlaca = true;
      tiempoPlacar = ahora;
      Serial.println(">> OPONENTE DETECTADO: PLACANDO");
    }

    if (ahora - tiempoPlacar < TIEMPO_PLACAR) {
      avanzarAmbos(VEL_PLACAR, VEL_PLACAR);
      Serial.println("PLACA: AMBOS MOTORES");
    }
    else {
      avanzarSoloMotorA();
      Serial.println("EMPUJE: SOLO MOTOR A");
    }
  }
  else {
    enPlaca = false;
    girarBusqueda();
    Serial.println("BUSCANDO...");
  }

  delay(50);
}